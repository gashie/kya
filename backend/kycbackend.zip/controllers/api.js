const axios = require("axios");
const stringSimilarity = require("string-similarity");
const jwt = require("jsonwebtoken");
const crypto = require("crypto");
const FormData = require("form-data");
const path = require("path");
const dotenv = require("dotenv");
const genTOTP = require("gen-totp");
dotenv.config({ path: "./config/config.env" });
const Model = require("../model/Customer");
const { sendOtp, Notify } = require("../helper/funcs");
const { sendMail } = require("../helper/external");
const {
  appHiveUrl,
  ServiceID,
  apiKey,
  apiToken,
  accountServiceID,
} = require("../myvars/module");
var base64ToImage = require("base64-to-image");
const Jimp = require("jimp");
const fs = require("fs");

const asynHandler = require("../middleware/async");

exports.CustomerUpdate = asynHandler(async (req, res, next) => {
  let frontimage = req.files.frontimage;
  let backimage = req.files.backimage;
  let pin = req.body.ghcardnumber;
  var Selfiepath = "ghCardSelfie/";
  var ghCardUploadLink = "./ghCardUpload/";
  var optionalObj = { fileName: pin, type: "png" };
  let custoemrData = req.kid;
  //check files for
  if (!frontimage) {
    return res.json({
      Status: 0,
      Message: "Please upload front image of your Ghana Card",
      Data: [],
    });
  }
  if (!backimage) {
    return res.json({
      Status: 0,
      Message: "Please upload back image of your Ghana Card",
      Data: [],
    });
  }

  if (!frontimage.mimetype.startsWith("image")) {
    return res.json({
      Status: 0,
      Message: "Please upload an image file",
      Data: [],
    });
  }

  if (!backimage.mimetype.startsWith("image")) {
    return res.json({
      Status: 0,
      Message: "Please upload an image file",
      Data: [],
    });
  }

  //change filename
  frontimage.name = `ghCardFront-${pin}${path.parse(frontimage.name).ext}`;
  console.log(`ghCardFront-${pin}${path.parse(frontimage.name).ext}`);
  frontimage.mv(`${ghCardUploadLink}${frontimage.name}`, async (err) => {
    if (err) {
      console.log(err);
      return res.json({
        Status: 0,
        Message: "Problem with file upload",
        Data: [],
      });
    }
  });

  backimage.name = `ghCardBack-${pin}${path.parse(backimage.name).ext}`;
  console.log(`ghCardBack-${pin}${path.parse(backimage.name).ext}`);
  backimage.mv(`${ghCardUploadLink}${backimage.name}`, async (err) => {
    if (err) {
      console.log(err);
      return res.json({
        Status: 0,
        Message: "Problem with file upload",
        Data: [],
      });
    }
  });
  var base64Str = req.body.image;
  if (!base64Str) {
    return res.json({
      Status: 0,
      Message: "Sorry, Please Take Selfie",
      Data: [],
    });
  }

  await base64ToImage(base64Str, Selfiepath, optionalObj);

  var imageInfo = await base64ToImage(base64Str, Selfiepath, optionalObj);
  let data = new FormData();
  data.append(
    "file-data",
    fs.createReadStream(`${Selfiepath}${pin}.${optionalObj.type}`)
  );
  data.append("pin", pin);
  data.append("ServiceID", ServiceID);
  data.append("apiKey", apiKey);
  data.append("apiToken", apiToken);

  let config = {
    method: "post",
    url: `${appHiveUrl}apihivetest/NIAVerification/facialVerrification`,
    headers: {
      ...data.getHeaders(),
    },
    data: data,
  };

  let response = await axios(config);

  //check string here

  if (response.data && response.data) {
    let ghcardname =
      response.data.Details !== null
        ? `${response.data.Details.forenames} ${response.data.Details.surname}`
        : "";
    var similarity = stringSimilarity.compareTwoStrings(
      custoemrData.fullName,
      ghcardname
    );

    console.log(similarity * 100);
    console.log(ghcardname);
    console.log(similarity * 100 > 70 ? "verified" : "pending");
    //SAVE RESSULT
    let newData = {
      customerHash: custoemrData?.customerHash,
      userAgentHash: custoemrData?.userAgentHash,
      customerID: custoemrData?.customerID,
      pin: pin,
      email: custoemrData.email,
      selfie: `${Selfiepath}${pin}`,
      frontpic: `${ghCardUploadLink}${frontimage.name}`,
      backpic: `${ghCardUploadLink}${backimage.name}`,
      customerGhanaCardData: JSON.stringify(response.data),
      status: similarity * 100 > 70 ? "verified" : "pending",
    };

    //now save new record
    let saveresult = await Model.SaveGhanaCard(newData);

    if (saveresult.affectedRows === 1 && response.data.Status == 1) {
      return clearResponse(
        "Process completed. We will notify you shortly",
        200,
        res
      );
    }

    if (saveresult.affectedRows === 1 && response.data.Status == 0) {
      return clearResponse(
        "Process completed. your data has been submitted to the bank for processing",
        200,
        res
      );
    }
  }

  res.json({
    Status: 0,
    Message: "Verification Failed",
    Data: response.data,
  });
});

exports.AccountEnquiry = asynHandler(async (req, res, next) => {
  let account = req.body.account;
  let agent = req.useragent;
  let dob = req.body.dob;
  console.log(req.body);
  console.log(agent);
  let newdob = new Date(req.body.dob).toDateString();
  let otp = genTOTP(`${account}${new Date().getDate()}`, {
    algorithm: "SHA-256",
    period: 1,
  });
  // let otp = "1100";
  let customerHash = crypto.createHash("md5").update(account).digest("hex");
  let userAgentHash = crypto
    .createHash("md5")
    .update(JSON.stringify(agent))
    .digest("hex");
  // if (!account || !dob) {
  //   res.json({
  //     Status: 0,
  //     Message: "Sorry, Please Provide Account Number And Dob",
  //     Data: [],
  //   });
  // }
  let data = JSON.stringify({
    servicerequest: {
      ServiceID: accountServiceID,
      apiKey: apiKey,
      apiToken: apiToken,
    },
    RequestData: {
      AccountToDebit: account,
    },
  });

  let config = {
    method: "post",
    url: `${appHiveUrl}apihivetest/payment/AccountEnquiry`,
    headers: {
      "Content-Type": "application/json",
    },
    data: data,
  };

  let response = await axios(config);

  if (response.data && response.data.Status == 1) {
    let accountData = JSON.parse(response.data.Details);
    let accountDate = accountData.date_of_birth;
    let phoneNumber = accountData.phoneno;
    let customerID = accountData.customer;
    let customerCategory = accountData.category;
    let customerName = accountData.ro_name;
    let email = accountData.email;
    let newAccountDate = new Date(accountDate).toDateString();
    console.log(newdob);
    console.log(newAccountDate);
    console.log(`checking dob--`, newdob == newAccountDate);
    if (newdob == newAccountDate) {
      //perform

      //search customerID in db
      let dbresult = await Model.FindCustomerID(customerID);
      console.log(`finding`, customerID);

      console.log(dbresult);
      if (dbresult) {
        res.json({
          Status: 0,
          Message:
            "[Dup]-Transaction cannot be completed at this time,please contact nearest branch",
          Data: [],
        });
      } else {
        await autoSave(
          phoneNumber,
          email,
          accountData,
          customerName,
          otp,
          customerID,
          customerHash,
          customerCategory,
          userAgentHash
        );
      }
    }

    if (newdob != newAccountDate) {
      res.json({
        Status: 0,
        Message: "Sorry,Contact any CalBank branch for assistance",
        Data: response.data,
      });
    }
  } else {
    res.json({
      Status: 0,
      Message: "Sorry,Contact any CalBank branch for assistance",
      Data: response.data,
    });
  }

  async function autoSave(
    phone,
    email,
    customer,
    customerName,
    otp,
    customerID,
    customerHash,
    customerCategory,
    userAgentHash
  ) {
    let newData = {
      customerHash,
      fullName: customerName,
      customerAccount: account,
      customerID,
      email,
      phone,
      customerCategory,
      otp: otp,
      customerData: JSON.stringify(customer),
      userAgentHash,
      status: "new",
    };

    //search for customer if account data exist
    let dbresult = await Model.FindCustomerAccount(account);
    console.log(dbresult);
    console.log(email);
    if (!dbresult) {
      console.log({
        Status: 0,
        Data: [],
        Message: `No record found--proceed to save new record`,
      });

      //now save new record
      let saveresult = await Model.SaveAccount(newData);
      //after approving and if all has approved set status to full-aproval / pending

      //generate and send otp
      let otpresponse = await sendOtp(phone, customerName, otp);
      console.log(otpresponse.data);
      if (saveresult.affectedRows === 1 && otpresponse.data.Status === 1) {
        // //set history
        sendResponse(customerHash, 200, res);
        console.log({
          Status: 1,
          Message: `Level One Completed`,
          kid: customerHash,
        });
      } else {
        res
          .status(500)
          .json({ Status: 0, Message: "Sorry Verification Failed" });
        console.log({
          Status: 0,
          Data: [],
          Message: `Db Error`,
        });
      }
    } else {
      console.log({
        Status: 0,
        Data: [],
        Message: `One record found--proceed to update  record`,
      });

      //now update existing record
      newData["updatedAt"] = new Date()
        .toISOString()
        .slice(0, 19)
        .replace("T", " ");
      newData["createdAt"] = new Date()
        .toISOString()
        .slice(0, 19)
        .replace("T", " ");
      newData["status"] = "new";
      let updateresult = await Model.UpdateAccount(newData, dbresult.id);
      //after approving and if all has approved set status to full-aproval / pending

      //generate and send otp
      let otpresponse = await sendOtp(phone, customerName, otp);
      console.log(otpresponse.data);
      if (updateresult.affectedRows === 1 && otpresponse.data.Status === 1) {
        // //set history
        sendResponse(dbresult.customerHash, 200, res);
        console.log({
          Status: 1,
          Message: `Level One Completed-updated`,
        });
      } else {
        res
          .status(500)
          .json({ Status: 0, Message: "Sorry Verification Failed" });
        console.log({
          Status: 0,
          Data: [],
          Message: `Db Error`,
        });
      }
    }
  }
});

exports.VerifyOtp = asynHandler(async (req, res, next) => {
  let custoemrData = req.kid;
  let otp = req.body.otp;
  if (!otp) {
    return res.json({
      Status: 0,
      Message: "Sorry, Please Provide Otp",
      Data: [],
    });
  }

  let dbresult = await Model.VerifyOtp(otp, custoemrData.email);

  if (!dbresult) {
    return res.status(200).json({
      Status: 0,
      Data: [],
      Message: `Invalid Otp`,
    });
  }
  let newData = {
    otp: "",
    status: "confirmed",
  };

  console.log({
    Status: 0,
    Data: [],
    Message: `Otp Verified--${dbresult.email} can proceed to ghana  card update`,
  });
  let updateresult = await Model.UpdateAccount(newData, dbresult.id);

  if (updateresult.affectedRows === 1) {
    // //set history

    res.status(200).json({
      Status: 1,
      Message: `Level two Completed`,
    });
    console.log({
      Status: 1,
      Message: `Level two Completed-veirfied`,
    });
  } else {
    res.status(500).json({ Status: 0, Message: "Sorry Verification Failed" });
    console.log({
      Status: 0,
      Data: [],
      Message: `Db Error`,
    });
  }
  //get history
});

const sendResponse = (kid, statusCode, res) => {
  const payload = {
    sub: kid,
    iss: "calbankgh.com",
    aud: "https://calbank.net/",
  };
  const token = jwt.sign(payload, process.env.JWTAUTH, {
    expiresIn: "10min",
  });

  const options = {
    // expires: new Date(Date.now() + 60 * 24 * 3600000),
    maxAge: 60 * 60 * 1000,
    httpOnly: true,
    secure: true,
    sameSite: "None",
  };

  if (process.env.NODE_ENV === "production") {
    options.secure = true;
  }
  res
    .status(statusCode)
    .cookie("sid", token, options)
    .json({ Status: 1, Message: "Level  Completed" });
};

const clearResponse = (message, statusCode, res) => {
  const options = {
    expires: new Date(Date.now() + 10 * 1000),
    httpOnly: true,
    secure: true,
    sameSite: "None",
  };

  res
    .status(statusCode)
    .cookie("sid", "none", options)
    .json({ Status: 1, Message: message });
};

exports.AllCustomers = asynHandler(async (req, res, next) => {
  let dbresult = await Model.GetCustomers();

  if (!dbresult) {
    return res.status(200).json({
      Status: 0,
      Data: [],
      Message: `No Record Found`,
    });
  }

  let bigData = [];

  for (const iterator of dbresult) {
    let dbresult = await Model.FindGhanaCardCustomer(iterator.email);
    let newData = {
      customerAccountHistory: iterator,
      customerGhanaCardData: dbresult,
    };

    bigData.push(newData);
  }

  res.status(200).json({
    Status: 1,
    Data: bigData,
    Message: `Record Found`,
  });
});

exports.ProcessCustomer = asynHandler(async (req, res, next) => {
  let id = req.body.id;

  let dbresult = await Model.FindCardByID(id);
  if (!dbresult) {
    console.log({
      Status: 0,
      Data: [],
      Message: `No record found`,
    });
    return res.json({
      Status: 0,
      Message: `No record found`,
      Data: [],
    });
  }

  let email = dbresult?.email;
  let customerExtraData = await Model.FindCustomer(email);
  let phone = customerExtraData.phone;
  let customer = JSON.parse(dbresult?.customerGhanaCardData);
  let customerID = dbresult?.customerID;
  let firstName = `${customer?.Details?.forenames}`;
  let issueDate = customer?.Details?.cardValidFrom || req.body.issueDate;
  let expiryDate = customer?.Details?.cardValidTo || req.body.expiryDate;
  let idNumber = customer?.Details?.nationalId || req.body.idNumber;
  let surname = `${customer?.Details?.surname}`;
  let idName = req.body.idName ? req.body.idName : `${firstName} ${surname}`;
  customerObject = { idName, issueDate, expiryDate, idNumber, customerID };
  console.log(dbresult);

  let data = JSON.stringify({
    servicerequest: {
      ServiceID: accountServiceID,
      apiKey: apiKey,
      apiToken: apiToken,
    },
    RequestData: {
      idName,
      issueDate,
      expiryDate,
      idNumber,
      customerID,
    },
  });

  let config = {
    method: "post",
    url: `${appHiveUrl}apihivetest/payment/UpdateGhanaCard`,
    headers: {
      "Content-Type": "application/json",
    },
    data: data,
  };

  let response = await axios(config);

  if (response.data && response.data.Status == 1) {
    //update customer update to processed
    let updatedAt = new Date().toISOString().slice(0, 19).replace("T", " ");
    let updateBody = {
      updatedAt,
      status: "processed",
    };

    let updateresult = await Model.UpdateProcess(updateBody, id);
    console.log(updateresult);
    if (updateresult.affectedRows === 1) {
      //Send otp
      //generate and send otp
      let otpresponse = await Notify(phone, idName);
      let emailresponse = await sendMail(idName, email);

      console.log({
        Status: 1,
        Message: `Process Update Completed`,
      });
      res.json({
        Status: 1,
        Message: `Process Update Completed`,
        Data: [],
      });
    } else {
      console.log({
        Status: 1,
        Message: `Process Update Failed`,
      });
      res.json({
        Status: 0,
        Message: `Process Update Failed`,
        Data: [],
      });
    }
  } else {
    console.log({
      Status: 1,
      Message: `Core Banking Update Failed for ${JSON.stringify(
        customerObject
      )}`,
    });
    res.json({
      Status: 0,
      Message: `Core Banking Update Failed for ${JSON.stringify(
        customerObject
      )}`,
      Data: [],
    });
  }
});
