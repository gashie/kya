const Model = require("../model/Cron");
const {
  appHiveUrl,
  apiKey,
  apiToken,
  accountServiceID,
} = require("../myvars/module");
const asynHandler = require("../middleware/async");
const { Notify } = require("../helper/funcs");
const axios = require("axios");
exports.ProcessUpdate = asynHandler(async (req, res, next) => {
  //get alert configurations
  //retrieve alert
  let dbresult = await Model.FindConfirmed();
  if (dbresult.length == 0) {
    console.log({
      Status: 0,
      Data: [],
      Message: `No record found`,
    });
  }

  //get details of customer ghana card
  for (const iterator of dbresult) {
    let customer = JSON.parse(iterator?.customerGhanaCardData);
    let customerID = iterator?.customerID;
    let firstName = `${customer?.Details?.forenames}`;
    let issueDate = customer?.Details?.cardValidFrom;
    let expiryDate = customer?.Details?.cardValidTo;
    let idNumber = customer?.Details?.nationalId;
    let surname = `${customer?.Details?.surname}`;
    let idName = `${firstName} ${surname}`;
    customerObject = { idName, issueDate, expiryDate, idNumber };
    let customerExtraData = await Model.FindCustomer(iterator.email);
    let phone = customerExtraData.phone
    let data = JSON.stringify({
      servicerequest: {
        ServiceID: accountServiceID,
        apiKey: apiKey,
        apiToken: apiToken,
      },
      RequestData: {
        idName,
        issueDate,
        expiryDate,
        idNumber,
        customerID,
      },
    });

    let config = {
      method: "post",
      url: `${appHiveUrl}apihivetest/payment/UpdateGhanaCard`,
      headers: {
        "Content-Type": "application/json",
      },
      data: data,
    };

    let response = await axios(config);

    if (response.data && response.data.Status == 1) {
      //update customer update to processed
      let updatedAt = new Date().toISOString().slice(0, 19).replace("T", " ");
      let updateBody = {
        updatedAt,
        status: "processed"
      };

      let updateresult = await Model.Update(updateBody, iterator.id);
      if (updateresult.affectedRows === 1) {
        let otpresponse = await Notify(phone, idName);
        console.log({
          Status: 1,
          Message: `Process Update Completed`,
        });
      } else {
        console.log({
          Status: 1,
          Message: `Process Update Failed`,
        });
      }
    } else {
      console.log({
        Status: 1,
        Message: `Core Banking Update Failed for ${JSON.stringify(customerObject)}`,
      });
    }
  }
});
