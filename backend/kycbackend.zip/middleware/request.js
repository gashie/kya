const asynHandler = require("./async");
const Model = require("../model/Customer");
exports.checkCard = asynHandler(async (req, res, next) => {
  let pin = req.body.ghcardnumber;
  let dbresult = await Model.FindGhCard(pin);

  if (dbresult) {
    return res.status(200).json({
      Status: 0,
      Data: [],
      Message: `Card has already been processed`,
    });
  }
  next();
});
