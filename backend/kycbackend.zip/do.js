const genTOTP = require('gen-totp');
  
  const otp = genTOTP('temst-keys',{algorithm:"SHA-256",period:1});

  console.log(otp);