const axios = require("axios");
const {
  smsUrl,
  apiKey,
  apiToken,
  smsServiceID,
} = require("../myvars/module");
module.exports = {

  sendOtp: async (phone,customerName,otp) => {
    console.log(customerName);
    let data = JSON.stringify({
      "servicerequest": {
        "ServiceID": smsServiceID,
        "apiKey": apiKey,
        "apiToken": apiToken
      },
      "PhoneNumber": phone,
      "Activity": "Customer Update",
      "Message": `Dear ${customerName.replace(/[ ,]+/g, ",").split(",")[0]} the OTP to verify your account update request is ${otp}`
    });
    
    let config = {
      method: 'post',
      url: smsUrl,
      headers: { 
        'Content-Type': 'application/json'
      },
      data : data
    };
 
    let response = await axios(config);
    return response
  },
  Notify: async (phone,customerName) => {
    console.log(customerName);
    let data = JSON.stringify({
      "servicerequest": {
        "ServiceID": smsServiceID,
        "apiKey": apiKey,
        "apiToken": apiToken
      },
      "PhoneNumber": phone,
      "Activity": "Customer Update",
      "Message": `Hello ${customerName.replace(/[ ,]+/g, ",").split(",")[0]} Your request to update your Ghana card on CalBank Banking System has been authorized/approved.Your profile has been updated successfully .`
    });
    
    let config = {
      method: 'post',
      url: smsUrl,
      headers: { 
        'Content-Type': 'application/json'
      },
      data : data
    };
 
    let response = await axios(config);
    return response
  },
};