const axios = require("axios");

module.exports = {

    sendMail: async (user,email) => {
      console.log(user,email);
        const config = {
          headers: {
            "Content-Type": "application/json",
          },
        };
        let { data } = await axios.post(
          `http://192.168.0.90:3113/api/v1/welcome/csupdate`,
         { email,user},
          config
        );
    
        console.log(data);
      },
};
