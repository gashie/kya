const express = require("express");
const { protect,CheckCompleted } = require("../../middleware/protect");
const { checkCard } = require("../../middleware/request");

const router = express.Router();
// App SETUP
const {
  CustomerUpdate,
  AccountEnquiry,
  VerifyOtp,
  AllCustomers,
  ProcessCustomer
} = require("../../controllers/api");

//routes for apps

router.route("/").post(protect,checkCard,CustomerUpdate);
router.route("/account").post(CheckCompleted,AccountEnquiry);
router.route("/otp").post(protect,VerifyOtp);
router.route("/all").post(AllCustomers);
router.route("/process").post(ProcessCustomer);



module.exports = router;
