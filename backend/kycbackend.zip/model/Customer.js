const pool = require("../config/db");

let cupdate = {};

cupdate.SaveAccount = (postData) => {
  return new Promise((resolve, reject) => {
    pool.query("INSERT INTO customer SET ?", [postData], (err, results) => {
      if (err) {
        return reject(err);
      }

      return resolve(results);
    });
  });
};



cupdate.SaveGhanaCard = (postData) => {
  return new Promise((resolve, reject) => {
    pool.query("INSERT INTO customerghanacardupdate SET ?", [postData], (err, results) => {
      if (err) {
        return reject(err);
      }

      return resolve(results);
    });
  });
};

cupdate.FindGhanaCardCustomer = (email) => {
  return new Promise((resolve, reject) => {
    const sql = "SELECT * FROM customerghanacardupdate WHERE email = ?";
    pool.query(sql, [email], function (error, results, fields) {
      if (error) {
        return reject(error);
      }
      return resolve(results[0]);
    });
  });
};

cupdate.FindCardByID = (id) => {
  return new Promise((resolve, reject) => {
    const sql = "SELECT * FROM customerghanacardupdate WHERE id = ? AND  status = 'pending'";
    pool.query(sql, [id], function (error, results, fields) {
      if (error) {
        return reject(error);
      }
      return resolve(results[0]);
    });
  });
};


cupdate.GetCustomers = () => {
  return new Promise((resolve, reject) => {
    const sql = "SELECT * FROM customer";
    pool.query(sql, function (error, results, fields) {
      if (error) {
        return reject(error);
      }
      return resolve(results);
    });
  });
};
cupdate.FindGhCard = (pin) => {
  return new Promise((resolve, reject) => {
    const sql = "SELECT * FROM customerghanacardupdate WHERE pin = ?";
    pool.query(sql, [pin], function (error, results, fields) {
      if (error) {
        return reject(error);
      }
      return resolve(results[0]);
    });
  });
};

cupdate.FindHash = (customerHash) => {
  return new Promise((resolve, reject) => {
    const sql = "SELECT * FROM customer WHERE customerHash = ?";
    pool.query(sql, [customerHash], function (error, results, fields) {
      if (error) {
        return reject(error);
      }
      return resolve(results[0]);
    });
  });
};

cupdate.Completed = (account) => {
  return new Promise((resolve, reject) => {
    const sql = `SELECT m.customerAccount FROM customer m INNER JOIN customerghanacardupdate c ON c.email = m.email WHERE m.customerAccount = ? AND (c.status != "processed" AND c.status != "verified" AND c.status != "pending");`
    pool.query(sql, [account], function (error, results, fields) {
      if (error) {
        return reject(error);
      }
      return resolve(results[0]);
    });
  });
};

cupdate.FindCustomer = (email) => {
    return new Promise((resolve, reject) => {
      const sql = "SELECT * FROM customer WHERE email = ?";
      pool.query(sql, [email], function (error, results, fields) {
        if (error) {
          return reject(error);
        }
        return resolve(results[0]);
      });
    });
  };

  cupdate.FindCustomerAccount = (account) => {
    return new Promise((resolve, reject) => {
      const sql = "SELECT * FROM customer WHERE customerAccount = ?";
      pool.query(sql, [account], function (error, results, fields) {
        if (error) {
          return reject(error);
        }
        return resolve(results[0]);
      });
    });
  };

  cupdate.FindCustomerID = (id) => {
    return new Promise((resolve, reject) => {
      const sql = "SELECT * FROM customer WHERE customerID = ?";
      pool.query(sql, [id], function (error, results, fields) {
        if (error) {
          return reject(error);
        }
        return resolve(results[0]);
      });
    });
  };

  
  

  cupdate.VerifyOtp = (otp,email) => {
    return new Promise((resolve, reject) => {
      const sql = `SELECT * FROM customer WHERE otp = ? AND email = ? AND status="new" AND NOW() <= DATE_ADD(createdAt, INTERVAL 40 MINUTE)`;
      pool.query(sql, [otp,email], function (error, results, fields) {
        if (error) {
          return reject(error);
        }
        return resolve(results[0]);
      });
    });
  };
  
cupdate.UpdateAccount = (postdata, id) => {
  return new Promise((resolve, reject) => {
    pool.query(
      "UPDATE customer SET ? WHERE id = ?",
      [postdata, id],
      (err, results) => {
        if (err) {
          return reject(err);
        }
        return resolve(results);
      }
    );
  });
};


cupdate.UpdateProcess = (postdata, id) => {
  return new Promise((resolve, reject) => {
    pool.query(
      "UPDATE customerghanacardupdate SET ? WHERE id = ?",
      [postdata, id],
      (err, results) => {
        if (err) {
          return reject(err);
        }
        return resolve(results);
      }
    );
  });
};
module.exports = cupdate;
