const pool = require("../config/db");

let monitdb = {};

monitdb.Find = () => {
  return new Promise((resolve, reject) => {
    const sql = "SELECT * FROM alert";
    pool.query(sql, function (error, results, fields) {
      if (error) {
        return reject(error);
      }
      return resolve(results);
    });
  });
};

monitdb.allConfigs = () => {
  return new Promise((resolve, reject) => {
    pool.query(
      "SELECT * FROM alert_config WHERE deletedAt IS NULL",
      (err, results) => {
        if (err) {
          return reject(err);
        }
        resolve(results);
      }
    );
  });
};

monitdb.FindGroup = (group) => {
  return new Promise((resolve, reject) => {
    const sql =
      "SELECT * FROM notification_group WHERE groupName = ? AND status = 1 AND deletedAt IS NULL";
    pool.query(sql,[group], function (error, results, fields) {
      if (error) {
        return reject(error);
      }
      return resolve(results[0]);
    });
  });
};

monitdb.CreateAlertConfig = (postData = req.body) => {
  return new Promise((resolve, reject) => {
    pool.query("INSERT INTO alert_config SET ?", [postData], (err, results) => {
      if (err) {
        return reject(err);
      }

      return resolve(results);
    });
  });
};

monitdb.createGroup = (postData = req.body) => {
  return new Promise((resolve, reject) => {
    pool.query(
      "INSERT INTO notification_group SET ?",
      [postData],
      (err, results) => {
        if (err) {
          return reject(err);
        }

        return resolve(results);
      }
    );
  });
};

monitdb.createAlert = (postData = req.body) => {
  return new Promise((resolve, reject) => {
    pool.query("INSERT INTO alert SET ?", [postData], (err, results) => {
      if (err) {
        return reject(err);
      }

      return resolve(results);
    });
  });
};
monitdb.FindPingState = (ip) => {
  return new Promise((resolve, reject) => {
    const sql = "SELECT * FROM pingstate WHERE ip = ?";
    pool.query(sql, [ip], function (error, results, fields) {
      if (error) {
        return reject(error);
      }
      return resolve(results[0]);
    });
  });
};

monitdb.update = (postdata, id) => {
  return new Promise((resolve, reject) => {
    pool.query(
      "UPDATE pingstate SET ? WHERE id = ?",
      [postdata, id],
      (err, results) => {
        if (err) {
          return reject(err);
        }
        return resolve(results);
      }
    );
  });
};
module.exports = monitdb;
