const dotenv = require("dotenv");
const mysql = require("mysql");
dotenv.config({ path: "../config/config.env" });

const pool = mysql.createPool({
  connectionLimit: 100,
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_DATABASE,
});

let monitdb = {};

monitdb.FindConfirmed = () => {
  return new Promise((resolve, reject) => {
    const sql = "SELECT * FROM customerghanacardupdate WHERE status = 'verified'";
    pool.query(sql, function (error, results, fields) {
      if (error) {
        return reject(error);
      }
      return resolve(results);
    });
  });
};
  
monitdb.Update = (postdata, id) => {
  return new Promise((resolve, reject) => {
    pool.query(
      "UPDATE customerghanacardupdate SET ? WHERE id = ?",
      [postdata, id],
      (err, results) => {
        if (err) {
          return reject(err);
        }
        return resolve(results);
      }
    );
  });
};

monitdb.FindCustomer = (email) => {
  return new Promise((resolve, reject) => {
    const sql = "SELECT * FROM customer WHERE email = ?";
    pool.query(sql, [email], function (error, results, fields) {
      if (error) {
        return reject(error);
      }
      return resolve(results[0]);
    });
  });
};
module.exports = monitdb;
