//module.js
let appHiveUrl = "http://10.10.30.72/";
let ServiceID = "6015";
let apiKey = "B44F735A-166E-467C-993D-F4077CC46CF2";
let apiToken = "3BC5F0C1-53EF-4021-BD08-BF3E6BD7E664";
let accountServiceID = "1010"
let smsServiceID = "1003"
let smsUrl = "http://10.10.30.72/apihive/apphive/sendsms"
let updateUrl = "http://10.211.55.3/apihivetest/payment/UpdateGhanaCard"
module.exports = {
  appHiveUrl,
  ServiceID,
  apiKey,
  apiToken,
  accountServiceID,
  smsServiceID,
  updateUrl,
  smsUrl
};
